/*
** EPITECH PROJECT, 2021
** B-MUL-200-LIL-2-1-myrpg-quentin.desmettre
** File description:
** main.c
*/

#include "../include/fight.h"

const sfTexture *draw_fight(fight_t *fight)
{
    sfRenderTexture_clear(fight->tex, sfBlack);
    sfRenderTexture_drawRectangleShape(fight->tex, fight->player, NULL);
    for (int i = 0; i < 20; i++)
        sfRenderTexture_drawRectangleShape(fight->tex, fight->dmg[i], NULL);
    for (int i = 0; i < 20; i++) {
        sfRenderTexture_drawRectangleShape(fight->tex, fight->solid[i], NULL);
    }
    sfRenderTexture_display(fight->tex);
    return sfRenderTexture_getTexture(fight->tex);
}

int touch_solid(sfFloatRect rect, fight_t *fight)
{
    sfFloatRect rect2;
    for (int i = 0; i < 20; i++) {
        rect2 = sfRectangleShape_getGlobalBounds(fight->solid[i]);
        if (sfFloatRect_intersects(&rect, &rect2, NULL))
            return (1);
    }
    return (0);
}

void fall(sfFloatRect *rect, fight_t *fight)
{
    if (touch_solid(*rect, fight) == 0) {
        sfRectangleShape_setPosition(fight->player,
        (sfVector2f){rect->left, rect->top});
        fight->fall += 1;
    } else {
        while (touch_solid(*rect, fight) == 1) {
            rect->top += fight->fall < 0 ? 1: -1;
        }
        sfRectangleShape_setPosition(fight->player,
        (sfVector2f){rect->left, rect->top});
        fight->fall = 0;
    }
}

void side_move(sfFloatRect *rect, fight_t *fight, int bool)
{
    if (touch_solid(*rect, fight) == 0) {
        sfRectangleShape_setPosition(fight->player,
        (sfVector2f){rect->left, rect->top});
    } else {
        while (touch_solid(*rect, fight) == 1)
            rect->left += bool;
        sfRectangleShape_setPosition(fight->player,
        (sfVector2f){rect->left, rect->top});
    }
}

void jump(sfFloatRect *rect, fight_t *fight)
{
    if (sfKeyboard_isKeyPressed(sfKeySpace) || sfKeyboard_isKeyPressed(sfKeyZ)) {
        rect->top += 1;
        if (touch_solid(*rect, fight) == 1)
            fight->fall = -25;
        rect->top -= 1;
    }
}

void move_pl_fight(fight_t *fight)
{
    sfFloatRect rect = sfRectangleShape_getGlobalBounds(fight->player);
    rect.top += fight->fall;
    fall(&rect, fight);
    jump(&rect, fight);
    if (sfKeyboard_isKeyPressed(sfKeyQ) || sfKeyboard_isKeyPressed(sfKeyD)) {
        rect.left += sfKeyboard_isKeyPressed(sfKeyQ) ? -5 : 5;
        side_move(&rect, fight, sfKeyboard_isKeyPressed(sfKeyQ) ? 1 : -1);
    }
}

static void draw(sfRenderWindow *win, fight_t *fight)
{
    const sfTexture* tex = draw_fight(fight);

    move_pl_fight(fight);
    sfSprite_setTexture(fight->sprt, tex, sfTrue);
    sfRenderWindow_drawSprite(win, fight->sprt, NULL);
    sfRenderWindow_display(win);
    sfRenderWindow_clear(win, sfBlack);
}

void fight_ev(sfRenderWindow *win, fight_t *fight, sfEvent event)
{
    sfKeyboard_isKeyPressed(sfKeyZ);
}

static void poll_events(sfRenderWindow *win, fight_t *fight)
{
    sfEvent ev;

    while (sfRenderWindow_pollEvent(win, &ev)) {
        if (ev.type == sfEvtClosed || sfKeyboard_isKeyPressed(sfKeyEscape))
            exit(0);
        fight_ev(win, fight, ev);
    }

}

void change_axe(fight_t *fight, int number)
{
    if (fight->x[number] >= 0 || fight->y[number] >= 0) {
        fight->x[number] = (fight->x[number] - fight->x[number]) - fight->x[number];
        fight->y[number] = (fight->y[number] - fight->y[number]) - fight->y[number];
    } else {
        fight->x[number] = abs(fight->x[number]);
        fight->y[number] = abs(fight->y[number]);
    }
}

void move_by(fight_t *fight, sfRenderWindow *win)
{
    sfVector2u size_win = sfRenderWindow_getSize(win);
    for (int i = 0; i < 20; i++) {
        sfVector2f pos_dmg = sfRectangleShape_getPosition(fight->dmg[i]);
        sfVector2f size_dmg = sfRectangleShape_getSize(fight->dmg[i]);
        sfVector2f new_pos = {(pos_dmg.x + fight->x[i]), (pos_dmg.y + fight->y[i])};
        sfRectangleShape_setPosition(fight->dmg[i], new_pos);
        if (new_pos.x <= 0 || new_pos.x >= (size_win.x - size_dmg.x)
            || new_pos.y <= 0 || new_pos.y >= (size_win.y - size_dmg.y)) {
            change_axe(fight, i);
        }
    }
}

void fill_ran_double(int size, int *x, int *y)
{
    for (int i = 0; i < size; i++) {
        int r = (rand() % (10 - 5 + 1)) + 5;
        int which = (rand() % (2 - 1 + 1)) + 1;
        if (((rand() % (2 - 1 + 1)) + 1) == 1)
            r = (r - r) - r;
        if (which == 1) {
            x[i] = r;
            y[i] = 0;
        } else {
            y[i] = r;
            x[i] = 0;
        }
    }
}

void set_dmg_pos(fight_t *fight, sfRenderWindow *win)
{
    for (int i = 15; i < 20; i++) {
        sfRectangleShape_setPosition(fight->dmg[i], (sfVector2f){50 * (2 + rand()
        % 36), 50 * (12 + rand() % 8)});
    }
}

void move_blocs(fight_t *fight, sfClock *clock_dmg, sfRenderWindow *win)
{
    sfTime time_dmg = sfClock_getElapsedTime(clock_dmg);
    float seconds = time_dmg.microseconds / 1000000.0;
    if (fight->test == 0) {
        fight->phase++;
        set_dmg_pos(fight, win);
        fill_ran_double(20, fight->x, fight->y);
    }
    if (seconds < 20) {
        // pattern_square(fight, 15);
        pattern_zigzag(fight, 15);
        fight->test = 1;
        move_by(fight, win);
    }
    if (seconds >= 20) {
        fight->test = 0;
        sfClock_restart(clock_dmg);
        if (fight->phase == 3)
            fight->phase = 0;
    }
}

fight_t *init_fight(void)
{
    fight_t *fight = malloc(sizeof(fight_t));

    fight->sprt = sfSprite_create();
    fight->fall = 0;
    fight->tex = sfRenderTexture_create(1920, 1080, 0);
    fight->player = sfRectangleShape_create();
    sfRectangleShape_setSize(fight->player, (sfVector2f){100, 100});
    sfRectangleShape_setFillColor(fight->player, sfGreen);
    sfRectangleShape_setPosition(fight->player, (sfVector2f){1000, 500});
    for (int i = 0; i < 20; i++) {
        fight->solid[i] = sfRectangleShape_create();
        fight->dmg[i] = sfRectangleShape_create();
        sfRectangleShape_setSize(fight->dmg[i], (sfVector2f){50, 50});
        sfRectangleShape_setSize(fight->solid[i], (sfVector2f){200, 100});
        sfRectangleShape_setFillColor(fight->solid[i], sfWhite);
        sfRectangleShape_setPosition(fight->solid[i], (sfVector2f){100 * (1 + rand()
        % 18), 100 * (6 + rand() % 4)});
        sfRectangleShape_setFillColor(fight->dmg[i], sfRed);
        // sfRectangleShape_setPosition(fight->dmg[i], (sfVector2f){50 * (2 + rand()
        // % 36), 50 * (12 + rand() % 8)});
    }
    fight->test = 0;
    fight->x = malloc(sizeof(int) * 20);
    fight->y = malloc(sizeof(int) * 20);
    fight->clock_zigzag = sfClock_create();
    fight->clock_square = sfClock_create();
    fight->zz = create_zigzag_pattern();
    fight->square = create_square_pattern();
    return (fight);
}

int main(void)
{
    sfRenderWindow *win = sfRenderWindow_create((sfVideoMode){1920, 1080, 32}, "MyRpg", sfClose | sfFullscreen, NULL);
    sfRenderWindow_setFramerateLimit(win, 60);
    srand(time(NULL));
    fight_t *fight = init_fight();
    sfClock *clock_dmg = sfClock_create();

    while (sfRenderWindow_isOpen(win)) {
        move_blocs(fight, clock_dmg, win);
        poll_events(win, fight);
        draw(win, fight);
    }
    return 0;
}
