/*
** EPITECH PROJECT, 2021
** my
** File description:
** libmy.h
*/

#ifndef LIBMY_H
    #define LIBMY_H
    #include "iomanip.h"
    #include "linked_list.h"
    #include "my_printf.h"
    #include "others.h"
    #include "strmanip.h"

#endif
