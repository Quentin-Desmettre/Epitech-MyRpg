#ifndef FIGHT_H
    #define FIGHT_H
    #include <unistd.h>
    #include <stdio.h>
    #include <stdarg.h>
    #include <SFML/Graphics.h>
    #include <SFML/Window.h>
    #include <SFML/Audio.h>
    #include <SFML/System.h>
    #include <math.h>
    #include <time.h>
    #include <sys/types.h>
    #include <sys/stat.h>
    #include <fcntl.h>
    #include <stdlib.h>
    #include <stdint.h>
    #include <stddef.h>
    #include <string.h>

typedef struct fight_t
{
    sfRectangleShape *solid[20];
    sfRectangleShape *dmg[20];
    sfRectangleShape *player;
    sfRenderTexture *tex;
    sfSprite *sprt;
    float fall;

    int test;
    int *x;
    int *y;
    int phase;

    sfClock *clock_zigzag;
    sfClock *clock_square;
    int *zz;
    int *square;
} fight_t;

void pattern_zigzag(fight_t *fight, int start);
void pattern_square(fight_t *fight, int start);
int *create_zigzag_pattern(void);
int *create_square_pattern(void);
void inverse_pattern(int *pattern, int size);

#endif
